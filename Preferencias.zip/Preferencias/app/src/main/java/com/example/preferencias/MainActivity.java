package com.example.preferencias;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;

import com.santalu.maskara.widget.MaskEditText;

import top.defaults.colorpicker.ColorObserver;
import top.defaults.colorpicker.ColorPickerPopup;
import top.defaults.colorpicker.ColorPickerView;

public class MainActivity extends AppCompatActivity {

    private TextView titulo, cor;
    private View previewDeCor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        titulo = findViewById(R.id.textViewTitulo);
        previewDeCor = findViewById(R.id.viewCorEscolhida);
        cor = findViewById(R.id.textViewCorEscolhida);

        ColorObserver co = new ColorObserver() {
            @Override
            public void onColor(int color, boolean fromUser, boolean shouldPropagate) {
                previewDeCor.setBackgroundColor(color);
                cor.setText(String.format("#%06X", (0xFFFFFF & color)));
            }
        };

        ColorPickerView cpv = findViewById(R.id.colorPicker);
        cpv.subscribe(co);
    }

    public void salvar(View view) {
        Switch swTema = findViewById(R.id.swTema);
        boolean temaEscuro = swTema.isActivated();

        ColorPickerView cpv = findViewById(R.id.colorPicker);
        int cor = cpv.getColor();

        MaskEditText edtCpf = findViewById(R.id.edtCpf);
        String cpf = edtCpf.getUnMasked().toString();

        RadioGroup rgSexo = findViewById(R.id.rgSexo);
        RadioButton rbSexo = findViewById(rgSexo.getCheckedRadioButtonId());

        CheckBox cbm = findViewById(R.id.cbMusica);
        CheckBox cbf = findViewById(R.id.cbFilmes);
        CheckBox cbj = findViewById(R.id.cbJogos);
        CheckBox cbs = findViewById(R.id.cbSeries);
        CheckBox cbl = findViewById(R.id.cbLivros);

        SeekBar sb = findViewById(R.id.seekbar);

        Spinner spIdiomas = findViewById(R.id.spIdioma);
        int idioma = (int) spIdiomas.getSelectedItemId();

        SharedPreferences pref = getSharedPreferences("setup_iftm", 0);
        SharedPreferences.Editor e = pref.edit();
        e.putBoolean("tema", temaEscuro);
        e.putInt("cor", cor);
        e.putString("cpf", cpf);
        e.putBoolean("sexo", rbSexo.isChecked());
        e.putBoolean("interesses", cbm.isChecked());
        e.putBoolean("interesses", cbf.isChecked());
        e.putBoolean("interesses", cbj.isChecked());
        e.putBoolean("interesses", cbs.isChecked());
        e.putBoolean("interesses", cbl.isChecked());
        e.putInt("volume", sb.getProgress());
        e.putLong("idiomas", spIdiomas.getSelectedItemId());
        e.apply();

        boolean t = pref.getBoolean("tema", false);
        swTema.setChecked(t);
        int c = pref.getInt("cor", getResources().getColor(R.color.rosa));
        cpv.setInitialColor(c);
        // CONSERTAR!
        String cpfsalvo = pref.getString("cpf", null);
        edtCpf.setText(cpfsalvo);
        // CONSERTAR!
        boolean s = pref.getBoolean("sexo", false);
        rgSexo.setActivated(s);
        boolean in = pref.getBoolean("interesses", false);
        cbm.setChecked(false);
        cbf.setChecked(false);
        cbj.setChecked(false);
        cbs.setChecked(false);
        cbl.setChecked(false);
        // CONSERTAR!
        int v = pref.getInt("volume", 50);
        sb.setProgress(v);
        long idi = pref.getInt("idiomas", 1);
    }
}